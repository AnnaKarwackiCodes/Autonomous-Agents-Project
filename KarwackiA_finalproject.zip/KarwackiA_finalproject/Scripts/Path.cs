﻿using UnityEngine;
using System.Collections;

public class Path : MonoBehaviour {

	//attribute
	public int position;
	public float radius = 5.0f;

	public float Radius
	{
		get{ return radius;}
	}
	public int Position
	{
		get{ return position;}
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}


}
