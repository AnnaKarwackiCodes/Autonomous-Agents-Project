﻿using UnityEngine;
using System.Collections;

public class Leader : Vehicle {
	//Class Field
	
	//steering Force
	private Vector3 ultimateForce;
	
	//object that we are going after
	public GameObject seekerTarget;
	
	//Weighting
	public float centeroidWeight = 60.0f;
	public float seekWeight = 75.0f;
	public float avoidWeight = 60.0f;
	public float alignWeight = 70.0f;
	public float separationWeight = 100.0f;

	// Use this for initialization
    override public void Start()
    {
        base.Start();
        ultimateForce = Vector3.zero;
    }

    protected override void CalcSteeringForce()
    {
        //reset steering force
        ultimateForce = Vector3.zero;
        //find nearest target
        //check for obstacle avoidance 
        //stay in bounds

        //for now, seek the target noodle
        //ultimateForce += Seek(seekerTarget.transform.position) * seekWeight;

        //obstacle avoidance
        GameObject[] obs = gm.Obstacles;
        for (int x = 0; x < obs.Length; x++)
        {
            ultimateForce += AvoidObstacle(obs[x]) * avoidWeight;
        }

        //Path following
        ultimateForce += PathFollow() * seekWeight;
		seekerTarget = currentPoint;

        //limit the steering force
        ultimateForce = Vector3.ClampMagnitude(ultimateForce, maxForce);

        // apply steering force to acceleration
        ApplyForce(ultimateForce);

        // debug lines
       // Debug.DrawLine(transform.position, seekerTarget.transform.position, Color.red);
    }

	protected Vector3 AvoidObstacle(GameObject ob)
	{
		//reset desired velocity
		desired = Vector3.zero;
		//get radius from obstacle's script
		float obRad = ob.GetComponent<ObstacleScript>().Radius;
		//get vector from vehicle to obstacle
		Vector3 vecToCenter = ob.transform.position - transform.position;
		//zero-out y component (only necessary when working on X-Z plane)
		vecToCenter.y = 0;
		//if object is out of my safe zone, ignore it
		if(vecToCenter.magnitude > safeDistance){
			return Vector3.zero;
		}
		//if object is behind me, ignore it
		if(Vector3.Dot(vecToCenter, transform.forward) < 0){
			return Vector3.zero;
		}
		//if object is not in my forward path, ignore it
		if(Mathf.Abs(Vector3.Dot(vecToCenter, transform.right)) > obRad + radius){
			return Vector3.zero;
		}
		
		//if we get this far, we will collide with an obstacle!
		//object on left, steer right
		if (Vector3.Dot(vecToCenter, transform.right) < 0) {
			desired = transform.right * maxSpeed;
			//debug line to see if the dude is avoiding to the right
			Debug.DrawLine(transform.position, ob.transform.position, Color.red);
		}
		else {
			desired = transform.right * -maxSpeed;
			//debug line to see if the dude is avoiding to the left
			Debug.DrawLine(transform.position, ob.transform.position, Color.green);
		}
		return desired;
	}
}
