﻿using UnityEngine;
using System.Collections;

public class StationRotate : MonoBehaviour {

	private Vector3 rotationAxis = Vector3.up;
	private float rotationSpeed = 5.0f;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
		transform.Rotate (rotationAxis, rotationSpeed * Time.deltaTime);
	}
}
