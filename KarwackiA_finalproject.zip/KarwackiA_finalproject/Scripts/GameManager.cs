﻿
using UnityEngine;
using System.Collections;

//add using System.Collections.Generic; to use the generic list format
using System.Collections.Generic;

public class GameManager : MonoBehaviour {
    
    // attributes
    public GameObject dude;
    public GameObject leader;
	public GameObject leader2;

    public GameObject dudePrefab;
    public GameObject targetPrefab;
    public GameObject obstaclePrefab;
	public GameObject PathPrefab;
    public GameObject leaderPrefab;
	public GameObject station;

    private GameObject[] obstacles;

	private GameObject[] pathPoints;

	private Vector3[] pointPos;

    // center of the flock
    private Vector3 centeroid;

    public Vector3 Centeroid
    {
        get { return centeroid; }
    }

    // average flock direction
    private Vector3 flockDirection;

    public Vector3 FlockDirection
    {
        get { return flockDirection; }
    }

    //how many flockers are there
    public int numberFlockers;

    // list of dudes
    private GameObject[] flock;

	private GameObject[] flock2;

	// object form of gameManager
	private GameObject gm;

	public GameObject[] Obstacles
	{
		get{return obstacles;}
	}
    public GameObject[] Flock
    {
        get { return flock; }
    }

	public GameObject[] PathPoints
	{
		get { return pathPoints; }
	}

	private bool pressed = false;
	private int angle = 0; // this is for the two different types of camera angles
	//-------------------------------------------
    // Start and Update
    //-------------------------------------------
	void Start () {
        numberFlockers = 20;
		//numberFlockers = 1;
        flock = new GameObject[numberFlockers];
		gm = GameObject.FindGameObjectWithTag ("Game Manager");

		pathPoints = new GameObject[10];
		pointPos = new Vector3[10];

        // make the leader
		Vector3 pos = new Vector3(15, 0, -186);
        leader = (GameObject)Instantiate(leaderPrefab,pos, Quaternion.identity);

		// placing and instantiating the station
		pos = new Vector3 (0, 0, 0);
		Instantiate(station,pos,Quaternion.identity);

        // make the flock 

        for (int x = 0; x < numberFlockers; x++)
        {
           // pos = new Vector3(Random.Range(-30f, 30f), 1.1f, Random.Range(-30f, 30f));
			pos = new Vector3(Random.Range(-15f, 15f), Random.Range(-10f, 10f), Random.Range(-186,-100));
			flock[x] = (GameObject) Instantiate(dudePrefab, pos, Quaternion.identity);
            flock[x].GetComponent<Seeker>().seekerTarget = leader;
        }

		//create obstacles and place them in the obstacles array
		for (int x = 0; x < 700; x++) 
        {
			pos = new Vector3 (Random.Range(-300f,300f),Random.Range(-300f,300f),Random.Range(-300f,300f));
			while(NearStation(pos))
			{
				pos = new Vector3 (Random.Range(-300f,300f),Random.Range(-300f,300f),Random.Range(-300f,300f));
			}
            Quaternion rot = Quaternion.Euler(pos);
			Instantiate(obstaclePrefab,pos,rot);
		}

		obstacles = GameObject.FindGameObjectsWithTag ("Obstacle");

		//making pre thought out path for the ship to travel
		pointPos [0] = new Vector3 (15, 0, -186);
		pointPos [1] = new Vector3 (-150, 0, 0);
		pointPos [2] = new Vector3 (0, 0, 125);
		pointPos [3] = new Vector3 (150, 0, 0);
		pointPos [4] = new Vector3 (0, -100, 0);
		pointPos [5] = new Vector3 (-150, 0, 0);
		pointPos [6] = new Vector3 (-207, 52, 30);
		pointPos [7] = new Vector3 (-207, 52, 78);
		pointPos [8] = new Vector3 (-140, 52, 106);
		pointPos [9] = new Vector3 (0, 100, 0);

		//create path points and place them in the pathPoints array
		for (int x = 0; x < pathPoints.Length; x++) 
		{
			pos = pointPos[x];
			pathPoints[x] = (GameObject) Instantiate(PathPrefab,pos,Quaternion.identity);
		}
		leader.GetComponent<Leader> ().seekerTarget = PathPrefab;



		// another leader with its crew
		// make the leader
		pos = new Vector3(0, 100, 0);
		leader2 = (GameObject)Instantiate(leaderPrefab,pos, Quaternion.identity);

		// make the flock 

		flock2 = new GameObject[numberFlockers];
		
		for (int x = 0; x < numberFlockers; x++)
		{
			// pos = new Vector3(Random.Range(-30f, 30f), 1.1f, Random.Range(-30f, 30f));
			pos = new Vector3(Random.Range(-30f, 20f), Random.Range(-100f, -70), Random.Range(-30,20));
			flock2[x] = (GameObject) Instantiate(dudePrefab, pos, Quaternion.identity);
			flock2[x].GetComponent<Seeker>().seekerTarget = leader2;
		}
		leader2.GetComponent<Leader> ().seekerTarget = PathPrefab;

		//set the camera to follow the GameManagerGO
		Camera.main.GetComponent<SmoothFollow> ().target = transform;
	}
	

	void Update () {

		for(int x = 0; x < numberFlockers;x++)
		{
			flock[x].GetComponent<Seeker>().TargetVelocity = leader.GetComponent<Leader>().Velocity;
		}

		gm.transform.position = leader.transform.position;

		if(Input.GetKey(KeyCode.LeftShift)&& pressed == false)
		{
			gm.transform.forward = leader.transform.right;
			//set the camera to follow the GameManagerGO
			Camera.main.GetComponent<SmoothFollow> ().target = transform;
			pressed = true;
			angle = 1;
		}
		else if(Input.GetKey(KeyCode.LeftShift)&& pressed)
		{
			//set the camera to follow the GameManagerGO
			Camera.main.GetComponent<SmoothFollow> ().target = null;
			pressed = false;
		}
		if(Input.GetKey(KeyCode.CapsLock)&& pressed == false)
		{
			gm.transform.forward = leader.transform.forward;
			//set the camera to follow the GameManagerGO
			Camera.main.GetComponent<SmoothFollow> ().target = transform;
			pressed = true;
			angle = 2;
		}
		else if(Input.GetKey(KeyCode.CapsLock)&& pressed)
		{
			//set the camera to follow the GameManagerGO
			Camera.main.GetComponent<SmoothFollow> ().target = null;
			pressed = false;
		}
		if(pressed)
		{
			if(angle == 1)
			{
				gm.transform.forward = leader.transform.right;
			}
			if(angle == 2)
			{
				gm.transform.forward = leader.transform.forward;
			}
			Camera.main.GetComponent<SmoothFollow> ().target = transform;
		}
	}

    // this searches for an obstacle and decides if you are near one if you need to worry
  bool NearStation(Vector3 position)
  {
		if(Vector3.Distance(station.transform.position, position)  < 100.0f)
		{
			return true;
		}
		else
		{
			return false;
		}
  }

    // this looks for the center of the flock to seek
    private void CalcCentroid()
    {
		centeroid = Vector3.zero;
        for (int x = 0; x < numberFlockers; x++)
        {
            centeroid += flock[x].transform.position;
        }
        centeroid = centeroid/numberFlockers;
    }

    // this figures out the average direction of the whole flock
    private void CalcFlockDirection()
    {
		flockDirection = Vector3.zero;
        for (int x = 0; x < numberFlockers; x++)
        {
            flockDirection += flock[x].transform.forward;
        }
		//flockDirection = flockDirection/numberFlockers;
        flockDirection = flockDirection.normalized; 
    }
}
