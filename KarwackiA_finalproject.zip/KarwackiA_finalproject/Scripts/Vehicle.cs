using UnityEngine;
using System.Collections;

//use the Generic system here to make use of a Flocker list later on
using System.Collections.Generic;

[RequireComponent(typeof(CharacterController))]

abstract public class Vehicle : MonoBehaviour {
    // attributes
    protected Vector3 acceleration;
    protected Vector3 velocity;
    protected Vector3 desired;

    public Vector3 Velocity 
    {
        get { return velocity; }
    }

    public float maxForce = 12.0f;
    public float maxSpeed;
    public float mass = 1;
    public float safeDistance = 5.0f;  
    public float radius;

    public float slowZone = 5.0f;

    CharacterController charControl;

	// Access to GameManager script
	protected GameManager gm;

	//path following stuff
	private int pathNum = 0; // this is so the vehicle will go to each spot
	private GameObject[] thePath;
	protected GameObject currentPoint;

	//leader following stuff
	protected Vector3 targetVelocity;
	public float behindLeaderDis = 5.0f;
	public Vector3 TargetVelocity
	{
		set{targetVelocity = value;}
		get{ return targetVelocity;}
	}

	virtual public void Start(){
		gm = GameObject.Find ("GameManagerGO").GetComponent<GameManager> ();
        acceleration = Vector3.zero;
        velocity = transform.forward;
        charControl = GetComponent<CharacterController>();
	}

	
	// Update is called once per frame
	protected void Update () {
        // calculate all nesscessary steering forces
        CalcSteeringForce();

        //add accel to vel
        velocity += acceleration * Time.deltaTime;
        //velocity.y = 0;

        // limit vel to max speed
        velocity = Vector3.ClampMagnitude(velocity, maxSpeed);

		//orientating the dude to face the noodle
		transform.forward = velocity.normalized;

        //move the character based on velocity
        charControl.Move(velocity * Time.deltaTime);

        // reset acceleration to 0
        acceleration = Vector3.zero;

	}

    abstract protected void CalcSteeringForce();

    protected void ApplyForce(Vector3 steeringForce)
    {
        acceleration += steeringForce / mass;
    }

    protected Vector3 Seek(Vector3 targetPosition)
    {
        desired = targetPosition - transform.position;
        desired = desired.normalized * maxSpeed;
        Vector3 steer = desired - velocity;
        //steer.y = 0;
        return steer;
    }

    protected Vector3 Flee(Vector3 targetPosition)
    {
        desired = targetPosition - transform.position;
        desired = desired.normalized * maxSpeed;
        Vector3 steer = desired - velocity;
        //steer.y = 0;
        return -steer;
    }
    public Vector3 Separation(float separationDistance)
    {
        List<Vector3> tooClose = new List<Vector3>();
        Vector3 distance;
        Vector3 steer = new Vector3();

        for (int x = 0; x < gm.numberFlockers; x++)
        {
            distance = gm.Flock[x].transform.position - transform.position;
            if ((distance.magnitude <= separationDistance) && distance.magnitude > 0)
            {
                tooClose.Add(gm.Flock[x].transform.position);
            }
        }

        for (int x = 0; x < tooClose.Count; x++)
        {
            steer += Flee(tooClose[x]).normalized;
        }

        steer = steer * (1 / separationDistance);
        steer = steer.normalized * maxSpeed;
        return steer - velocity;
    }

    public Vector3 Alignment(Vector3 alignVector)
    {
        Vector2 steer = new Vector2();
        desired = alignVector * maxSpeed;
        steer = desired - velocity;
        return steer;
    }

    public Vector3 Cohension(Vector3 cohesionVector)
    {

        return Seek(cohesionVector);
    }

    public Vector3 StayInBounds(float radius, Vector3 center)
    {
        return Vector3.zero;
    }

	public Vector3 PathFollow()
	{
		thePath = gm.PathPoints;

		if(Vector3.Distance(thePath[pathNum].transform.position,transform.position) < 3.0f)
		{
			pathNum++;
		}
		else
		{
			currentPoint = thePath[pathNum];
			return Seek(thePath[pathNum].transform.position);
		}

		if(pathNum == thePath.Length)
		{
			pathNum = 0;
		}
		return Vector3.zero;

	}

    public Vector3 Arrival(Vector3 targetPosition)
    {
        // calculate the desired velocity
        desired = targetPosition - transform.position;
        float distance = desired.magnitude;

        // if it is within the slowZone start slowing down
        if (distance < slowZone)
        {
            //inside the slow zone
            desired = desired.normalized * maxSpeed * (distance/slowZone);
        }
        else 
        {
            // outside the slow zone
            desired = desired.normalized * maxSpeed;
        }
		desired -= velocity;
        return desired;
    }

    public Vector3 Evade(Vector3 targetPosition, Vector3 targetVelocity)
    {
        Vector3 futurePos = targetPosition + targetVelocity * 10;
        return Flee(futurePos);
    }

	public Vector3 LeaderFollow(Vector3 leaderPosition,float sepWeight)
	{
		Vector3 behind = targetVelocity * -1;
		behind = behind.normalized * behindLeaderDis;
		behind = leaderPosition + behind;

		desired = Arrival (behind) * 400;

		//if you are in the way of the leader, beat it buster
		Vector3 ahead = TargetVelocity.normalized * behindLeaderDis;
		ahead = leaderPosition + ahead;

		if(Vector3.Distance(ahead,transform.position)<= 25 || Vector3.Distance(leaderPosition,transform.position) <=25)
		{
			desired += Evade(leaderPosition, targetVelocity) * 1000;
		}
				
		// dont have all the drones pile up on each other
		desired += Separation (10) * 200;

		return desired;
	}
}
