﻿using UnityEngine;
using System.Collections;

public class Cameras : MonoBehaviour {

    public float speed = 10.0f;
    float x = 0;
    float y = 0;
    float z = 0;
	Vector3 point;
	bool pressed = false;

	public GameObject look;

	//GameManager gm = new GameManager();

	// Use this for initialization
	void Start () {
		point = new Vector3 (0, 0, 0);
		//transform.LookAt (look.transform.position);
		transform.LookAt (point);
	}
	
	// Update is called once per frame
	void Update () {
        x = 0;
        y = 0;
        z = 0;

	    if (Input.GetMouseButton (0)&& Input.GetKey("r"))
	    {
	        z = speed * Input.GetAxis("Mouse X");
			transform.Translate(x,y,z);
	    }
		if(Input.GetMouseButton (0)&& Input.GetKey("e"))
		{
			transform.RotateAround(transform.position,Vector3.up, Input.GetAxis("Mouse X") * speed);
			//transform.RotateAround(transform.position,Vector3.right, Input.GetAxis("Mouse Y") * speed);
		}
		if(Input.GetMouseButton (0)&& Input.GetKey("w"))
	    {		
			x = speed * Input.GetAxis("Mouse X");
			y = speed * Input.GetAxis("Mouse Y");
			transform.Translate(x,y,z);
	    } 

	}
}
