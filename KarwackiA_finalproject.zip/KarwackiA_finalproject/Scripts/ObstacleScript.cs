﻿using UnityEngine;
using System.Collections;

public class ObstacleScript : MonoBehaviour {

	public float radius;

	public float Radius
	{
		get{return radius;}
	}
	
}

	